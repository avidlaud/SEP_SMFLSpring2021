# League Service

To start the server on your local machine, type `node index.js` in this directory. Make sure you have all dependencies installed, if not run `npm install`.
